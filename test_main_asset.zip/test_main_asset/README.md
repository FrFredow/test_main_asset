# test_main_asset
